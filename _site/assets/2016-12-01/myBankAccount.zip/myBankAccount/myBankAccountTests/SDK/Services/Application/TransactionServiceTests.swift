//
//  TransactionServiceTests.swift
//  myBankAccountTests
//
//  Created by Kothari, Sagar on 12/6/17.
//  Copyright © 2017 Kothari, Sagar. All rights reserved.
//

import UIKit
import CoreData
import XCTest
@testable import myBankAccount

class TransactionServiceTests: XCTestCase {
    var userDefaultsToBeUsed: UserDefaults!
    var sut = TransactionService()
    var coreDataManager: CoreDataManager!
    var walletService: WalletService!
    var defaultAccount = (name: "Sagar", email: "sag333ar@gmail.com", initialBalance: Int32(10000))
    var defaultTransaction = (desc: "Just need cash", isDebit: true, amount: 1000, timeStamp: Date())
    
    override func setUp() {
        super.setUp()
        walletService = WalletService()
        userDefaultsToBeUsed = UserDefaults.createCleanForTest()
        // TODO: Need to create mock instance of core data
        coreDataManager = CoreDataManager.shared
        cleanUpCoreData()
    }
    
    func cleanUpCoreData() {
        let fetchRequestAccount: NSFetchRequest<Account> = Account.fetchRequest()
        let deleteRequestAccount = NSBatchDeleteRequest(fetchRequest: fetchRequestAccount as! NSFetchRequest<NSFetchRequestResult>)
        let _ = try? coreDataManager.context.execute(deleteRequestAccount)
        
        let fetchRequestTransactions: NSFetchRequest<Transaction> = Transaction.fetchRequest()
        let deleteRequestTransactions = NSBatchDeleteRequest(fetchRequest: fetchRequestTransactions as! NSFetchRequest<NSFetchRequestResult>)
        let _ = try? coreDataManager.context.execute(deleteRequestTransactions)
    }
    
    override func tearDown() {
        super.tearDown()
    }
    
    func executeCreateWallet(_ account: (name: String, email: String, initialBalance: Int32)) -> WalletDTO {
        return walletService.createWallet(account.name,
                                email: account.email,
                                initialBalance: account.initialBalance,
                                userDefaults: userDefaultsToBeUsed,
                                coreDataManager: coreDataManager)
    }

    func testGetTransactions_shouldReturnZeroRecords() {
        let walletDTOInstance = executeCreateWallet(defaultAccount)
        let arrayOfTransactions = sut.getTransactions(walletDTOInstance)
        XCTAssertEqual(0, arrayOfTransactions.count)
    }

    func testWithdrawl_shouldReturnValidTransactionDTO() {
        let walletDTOInstance = executeCreateWallet(defaultAccount)
        let transactionDTO = sut.withdrawl(defaultTransaction.desc,
                                           amount: defaultTransaction.amount,
                                           walletDTO: walletDTOInstance,
                                           timeStamp: defaultTransaction.timeStamp,
                                           coreDataManager: coreDataManager)
        XCTAssertNotNil(transactionDTO)
        XCTAssertEqual(defaultTransaction.amount, transactionDTO.amount)
        XCTAssertEqual(defaultTransaction.desc, transactionDTO.desc)
        XCTAssertEqual(defaultTransaction.timeStamp, transactionDTO.timeStamp)
        XCTAssertEqual(defaultTransaction.isDebit, true)
    }

}
