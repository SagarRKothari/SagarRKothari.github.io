//
//  UserDefaultsManager.swift
//  myBankAccount
//
//  Created by Kothari, Sagar on 12/6/17.
//  Copyright © 2017 Kothari, Sagar. All rights reserved.
//

import UIKit


class UserDefaultsManager: NSObject {
    static var getUserDefaults: UserDefaults {
        return UserDefaults.standard
    }
}
