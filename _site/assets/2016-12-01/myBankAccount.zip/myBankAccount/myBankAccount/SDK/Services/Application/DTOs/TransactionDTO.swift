//
//  TransactionDTO.swift
//  myBankAccount
//
//  Created by Kothari, Sagar on 12/6/17.
//  Copyright © 2017 Kothari, Sagar. All rights reserved.
//

import UIKit

class TransactionDTO: NSObject {
    let desc: String
    let isDebit: Bool
    let amount: Int32
    let timeStamp: Date

    override init() {
        desc = ""
        isDebit = true
        amount = 0
        timeStamp = Date()
        super.init()
    }
    
    init(_ desc: String,
         isDebit: Bool,
         amount: Int32,
         timeStamp: Date) {
        self.desc = desc
        self.isDebit = isDebit
        self.amount = amount
        self.timeStamp = timeStamp
        super.init()
    }

}
