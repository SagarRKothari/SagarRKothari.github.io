//
//  WalletService.swift
//  myBankAccount
//
//  Created by Kothari, Sagar on 12/6/17.
//  Copyright © 2017 Kothari, Sagar. All rights reserved.
//

import UIKit

let accountExistsKey = "accountExists"

class WalletService: NSObject, InterfaceWalletService {

    func doesWalletExists(_ userDefaults: UserDefaults) -> Bool {
        // let userDefaults = UserDefaultsManager.getUserDefaults
        return userDefaults.value(forKey: accountExistsKey) != nil
    }
    
    func createWallet(_ name: String,
                      email: String,
                      initialBalance: Int32,
                      userDefaults: UserDefaults,
                      coreDataManager: CoreDataManager) -> WalletDTO {
        // let userDefaults = UserDefaultsManager.getUserDefaults
        let walletInstance = Account(context: coreDataManager.context)
        walletInstance.name = name
        walletInstance.email = email
        walletInstance.balance = initialBalance
        coreDataManager.saveContext()
        let number = NSNumber(value: true)
        userDefaults.setValue(number, forKey: accountExistsKey)
        userDefaults.synchronize()
        return WalletDTO(walletInstance.name!,
                                          email: walletInstance.email!,
                                          initialBalance: walletInstance.balance)
        
    }
    
    func terminateWallet(_ walletDTOInstance: WalletDTO,
                         userDefaults: UserDefaults,
                         coreDataManager: CoreDataManager) {
        if let account = CoreDataManager.shared.getAccount(walletDTOInstance) {
            if let transactions = account.transactions?.allObjects {
                for transaction in transactions {
                    if let trxn = transaction as? Transaction {
                        CoreDataManager.shared.context.delete(trxn)
                    }
                }
            }
            CoreDataManager.shared.context.delete(account)
            CoreDataManager.shared.saveContext()
        }
        userDefaults.removeObject(forKey: accountExistsKey)
        userDefaults.synchronize()
    }

}
