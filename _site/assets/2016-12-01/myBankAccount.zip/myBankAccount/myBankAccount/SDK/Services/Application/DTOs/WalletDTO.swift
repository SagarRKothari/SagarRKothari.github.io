//
//  Wallet.swift
//  myBankAccount
//
//  Created by Kothari, Sagar on 12/6/17.
//  Copyright © 2017 Kothari, Sagar. All rights reserved.
//

import UIKit

class WalletDTO: NSObject {
    let name: String
    let email: String
    let initialBalance: Int32

    override init() {
        name = ""
        email = ""
        initialBalance = 0
        super.init()
    }

    init(_ name: String, email: String, initialBalance: Int32) {
        self.name = name
        self.email = email
        self.initialBalance = initialBalance
        super.init()
    }

}
