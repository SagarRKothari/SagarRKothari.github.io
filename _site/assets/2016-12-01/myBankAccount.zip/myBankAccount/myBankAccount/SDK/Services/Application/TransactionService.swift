//
//  TransactionService.swift
//  myBankAccount
//
//  Created by Kothari, Sagar on 12/6/17.
//  Copyright © 2017 Kothari, Sagar. All rights reserved.
//

import UIKit

class TransactionService: NSObject {

    func getTransactions(_ walletDTOInstance: WalletDTO) -> [TransactionDTO] {
        if let account = CoreDataManager.shared.getAccount(walletDTOInstance) {
            var arrayOfTransactionDTOs: [TransactionDTO] = []
            if let arrayOfTransactions = account.transactions?.allObjects as? [Transaction] {
                for transaction in arrayOfTransactions {
                    arrayOfTransactionDTOs.append(
                        TransactionDTO(transaction.desc!,
                                       isDebit: transaction.isDebit,
                                       amount: transaction.amount,
                                       timeStamp: transaction.timestamp!)
                    )
                }
            }
            return arrayOfTransactionDTOs
        }
        return []
    }
    
//    func get

    func withdrawl(_ desc: String,
                   amount: Int32,
                   walletDTO: WalletDTO,
                   timeStamp: Date,
                   coreDataManager: CoreDataManager) -> TransactionDTO? {
        if let account = CoreDataManager.shared.getAccount(walletDTO) {
            let transactionInstance = Transaction(context: coreDataManager.context)
            transactionInstance.desc = desc
            transactionInstance.isDebit = true
            transactionInstance.timeStamp = timeStamp
            transactionInstance.amount = amount
            transactionInstance.account = account
            coreDataManager.saveContext()
        }
        return nil
    }
}
