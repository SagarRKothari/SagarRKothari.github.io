//
//  InterfaceWalletService.swift
//  myBankAccount
//
//  Created by Kothari, Sagar on 12/6/17.
//  Copyright © 2017 Kothari, Sagar. All rights reserved.
//

import Foundation

protocol InterfaceWalletService {
    func doesWalletExists(_ userDefaults: UserDefaults) -> Bool
    func createWallet(_ name: String,
                      email: String,
                      initialBalance: Int32,
                      userDefaults: UserDefaults,
                      coreDataManager: CoreDataManager) -> WalletDTO
    func terminateWallet(_ wallet: WalletDTO,
                         userDefaults: UserDefaults,
                         coreDataManager: CoreDataManager)
}
