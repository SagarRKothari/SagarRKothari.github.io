//
//  WalletServiceTests.swift
//  myBankAccountTests
//
//  Created by Kothari, Sagar on 12/6/17.
//  Copyright © 2017 Kothari, Sagar. All rights reserved.
//

import UIKit
import CoreData
import XCTest
@testable import myBankAccount

extension UserDefaults {
    private static var index = 0
    static func createCleanForTest(label: StaticString = #file) -> UserDefaults {
        index += 1
        let suiteName = "UnitTest-UserDefaults-\(label)-\(index)"
        UserDefaults().removePersistentDomain(forName: suiteName)
        return UserDefaults(suiteName: suiteName)!
    }
}

class WalletServiceTests: XCTestCase {

    var userDefaultsToBeUsed: UserDefaults!
    var sut = WalletService()
    var coreDataManager: CoreDataManager!
    var defaultAccount = (name: "Sagar", email: "sag333ar@gmail.com", initialBalance: Int32(10000))

    override func setUp() {
        super.setUp()
        userDefaultsToBeUsed = UserDefaults.createCleanForTest()
        // TODO: Need to create mock instance of core data
        coreDataManager = CoreDataManager.shared
        cleanUpCoreData()
    }

    func cleanUpCoreData() {
        let fetchRequestAccount: NSFetchRequest<Account> = Account.fetchRequest()
        let deleteRequestAccount = NSBatchDeleteRequest(fetchRequest: fetchRequestAccount as! NSFetchRequest<NSFetchRequestResult>)
        let _ = try? coreDataManager.context.execute(deleteRequestAccount)
        
        let fetchRequestTransactions: NSFetchRequest<Transaction> = Transaction.fetchRequest()
        let deleteRequestTransactions = NSBatchDeleteRequest(fetchRequest: fetchRequestTransactions as! NSFetchRequest<NSFetchRequestResult>)
        let _ = try? coreDataManager.context.execute(deleteRequestTransactions)
    }

    override func tearDown() {
        super.tearDown()
    }
    
    func executeCreateWallet(_ account: (name: String, email: String, initialBalance: Int32)) -> WalletDTO {
        return sut.createWallet(account.name,
                                email: account.email,
                                initialBalance: account.initialBalance,
                                userDefaults: userDefaultsToBeUsed,
                                coreDataManager: coreDataManager)
    }
    
    func testDoesWalletExists_afterCreatingWallet() {
        let walletDTOInstance = executeCreateWallet(defaultAccount)
        XCTAssertTrue(sut.doesWalletExists(userDefaultsToBeUsed))
        XCTAssertNotNil(coreDataManager.getAccount(walletDTOInstance))
    }

    func testDoesWalletExists_beforeCreatingWallet() {
        XCTAssertEqual(0, coreDataManager.getAllAccounts().count)
        XCTAssertFalse(sut.doesWalletExists(userDefaultsToBeUsed))
    }
    
    func testCreateWallet_retunsValidDTO() {
        let walletDTOInstance = executeCreateWallet(defaultAccount)
        XCTAssertEqual(defaultAccount.name, walletDTOInstance.name)
        XCTAssertEqual(defaultAccount.email, walletDTOInstance.email)
        XCTAssertEqual(defaultAccount.initialBalance, walletDTOInstance.initialBalance)
    }
    
    func testTerminateWallet_didUpdateUserDefaults() {
        let walletDTOInstance = executeCreateWallet(defaultAccount)
        sut.terminateWallet(walletDTOInstance, userDefaults: userDefaultsToBeUsed, coreDataManager: coreDataManager)
        XCTAssertFalse(sut.doesWalletExists(userDefaultsToBeUsed))
    }

    func testTerminateWallet_didDeleteAccount() {
        let walletDTOInstance = executeCreateWallet(defaultAccount)
        sut.terminateWallet(walletDTOInstance, userDefaults: userDefaultsToBeUsed, coreDataManager: coreDataManager)
        XCTAssertNil(coreDataManager.getAccount(walletDTOInstance))
    }
    
    func testTerminateWallet_shouldNotDeleteAccountWithInvalidDTO() {
        let _ = executeCreateWallet(defaultAccount)
        let walletDTOInstance = WalletDTO("Javal",
                                          email: "javal@equalexpert.com",
                                          initialBalance: 100000)
        sut.terminateWallet(walletDTOInstance,
                            userDefaults: userDefaultsToBeUsed,
                            coreDataManager: coreDataManager)
        XCTAssertEqual(1, coreDataManager.getAllAccounts().count)
    }

}
